#include <stdio.h>

int main(){
	int n1,n2;
	int r;
	printf("Enter two numbers:");
	scanf("%d %d",&n1,&n2);
	r =n1&n2;
	printf("%d&%d=%d\n",n1,n2,r);
	r =n1|n2;
	printf("%d|%d=%d\n",n1,n2,r);
	r =n1^n2;
	printf("%d^%d=%d\n",n1,n2,r);
	r =n1>>2;
	printf("%d>>%d=%d\n",n1,2,r);
	r = n2<<2;
	printf("%d<<%d=%d\n",n2,2,r);
	return 0;
}
