#include <stdio.h>

int main(){
	int l,w;
	int area;
	printf("Enter the length of rectangle = ");
	scanf("%d",&l);
	printf("Enter the width of rectangle = ");
	scanf("%d",&w);
	area = l*w;
	printf("Area of the rectangle = %d",area);
	return 0;
}
