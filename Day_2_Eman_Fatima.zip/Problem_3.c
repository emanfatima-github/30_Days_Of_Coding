#include <stdio.h>

int main(){
	int n1;
	float n2;
	printf("First number:");
	scanf("%d",&n1);
	printf("Second number:");
	scanf("%f",&n2);
	if(n1==n2)
	printf("1");
	else
	printf("0");
	return 0;
}
