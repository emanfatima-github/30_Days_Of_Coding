#include <stdio.h>

int main(){
	int i,sum = 0;
	float avg;
	printf("Enter five numbers: ");
	for(i=1; i<=5; i++){
		scanf("%d",&i);
		sum += i;
	}
	printf("Sum: %d\n",sum);
	avg = sum/5;
	printf("Average: %.2f",avg);
	return 0;
}
