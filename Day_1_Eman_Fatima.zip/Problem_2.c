#include <stdio.h>

int main(){
	printf("This is Master in \"C language\"30 days course.\n");
	printf("This course is organized by TECH INVOLVERS.");
	return 0;
}
