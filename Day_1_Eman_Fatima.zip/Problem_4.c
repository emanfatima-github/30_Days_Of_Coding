#include <stdio.h>

int main(){
	printf(" ____ \t\t\t\t      ____\n");
	printf("|____|  >>-----------------------<<  |____|\n");
	printf("\n");
	printf("|----->                             <-----|\n");
	printf("|---------->                   <----------|\n");
	printf("|----->                             <-----|\n");
	return 0;
}
