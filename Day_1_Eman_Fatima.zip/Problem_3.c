#include <stdio.h>

int main(){
	printf(" _____\n");
	printf("|");
	printf("_____\n");
	printf("|");
	printf("_____\n");
	return 0;
}
