#include <stdio.h>

int main(){
	int n1,n2,n3;
	printf("Enter three numbers:");
	scanf("%d %d %d",&n1,&n2,&n3);
	if(n1==n2 && n2==n3){
	printf("All Numbers are same");
	}else if(n1<n2 && n1<n3){
	printf("Smallest Number : %d",n1);
	}else if(n2<n1 && n2<n3){
	printf("Smallest Number : %d",n2);
	}else{ //if(n3<n1 && n3<n2)
	printf("Smallest Number : %d\n",n3);
    }
	if(n1>n2 && n1>n3)
	printf("Greatest Number : %d\n",n1);
	else if(n2>n1 && n2>n3)
	printf("Greatest Number : %d\n",n2);
	else if(n3>n1 && n3>n2)
	printf("Greatest Number : %d\n",n3);
	return 0;
}
