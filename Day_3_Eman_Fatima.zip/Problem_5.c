#include <stdio.h>

int main(){
	char consumer_type;
	int units_consumed;
	float e_cost,total_bill,gst;
	printf("Select the Consumer type:\n");
	printf("C for commercial.\n");
	printf("H for home.\n");
	printf("Enter consumer type:");
	scanf(" %c",&consumer_type);
	printf("Enter number of units consumed:");
	scanf("%d",&units_consumed);
	
	if(consumer_type == 'H'){
		if(units_consumed <= 100){
			e_cost = units_consumed * 11.0;
		}else if(units_consumed<=200){
			e_cost = 100 * 11.0 + (units_consumed - 100) * 15.0;
		}else{
			 e_cost = 100 * 11.0 + 100 * 15.0 + (units_consumed - 200) * 20.0;
		}
	    gst = 0.1 * e_cost;
        total_bill = e_cost + gst + 700.0;
    } else if (consumer_type == 'C' || consumer_type == 'c') {
        if (units_consumed <= 100) {
            e_cost = units_consumed * 15.0;
        } else if (units_consumed <= 200) {
            e_cost = 100 * 15.0 + (units_consumed - 100) * 22.0;
        } else {
            e_cost = 100 * 15.0 + 100 * 22.0 + (units_consumed - 200) * 30.0;
        }
        gst = 0.15 * e_cost;
        total_bill = e_cost + gst + 1100.0;
    }
    printf("Electricity Cost: %.2f rupees\n", e_cost);
    printf("GST: %.2f rupees\n", gst);
    printf("Net Electricity Bill: %.0f rupees\n", total_bill);

    return 0;
}
