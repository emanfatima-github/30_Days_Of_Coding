#include <stdio.h>
#include <stdlib.h>

int main(){
	srand(time(0));
	int x = rand() %90+10;
	int y = rand() %90+10;
	int sum;
	printf("Two random numbers:%d %d\n",x,y);
	if(y<x)
		sum = x+y;
	else
		sum = y+x;
	if(sum%2==0)
	printf("Their sum is even.");
	else
	printf("Their sum is odd.");
	return 0;
}
