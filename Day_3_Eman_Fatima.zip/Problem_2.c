#include <stdio.h>

int main(){
	int a,b,c;
	printf("Enter three angles of a triangle:");
	scanf("%d %d %d",&a,&b,&c);
	int sum = 180;
	if(a+b+c == sum)
	printf("Yes,such triangle is possible.");
	else
	printf("Sorry,Such triangle can't exist");
	return 0;
}
